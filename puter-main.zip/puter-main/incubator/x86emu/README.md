# Research + Planning for x86 Emulation in Puter

## Resources
- [copy.sh/v86 docs](https://github.com/copy/v86/blob/master/docs)
- [greenfield github](https://github.com/udevbe/greenfield)

## TODO

### Documents to Write

- [ ] specification for Puter network driver
- [ ] specification for Puter network relay

### Things to Try

- [ ] greenfield/wayland/arch/v86
- [ ] puter-fuse in v86
