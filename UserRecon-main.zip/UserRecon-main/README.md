# UserRecon
Find usernames across over 75 social networks This is useful if you are running an investigation to determine the usage of the same username on different social networks.


# Install Linux

<pre><span class="pl-c"></span> #command </span>

$ apt update && apt upgrade 

$ apt install git 

$ git clone https://github.com/AL-AlamySploit/UserRecon

$ cd UserRecon

$ chmod +x userrecon.sh 

$ bash userrecon.sh</span></pre>

# Video explanation

wait..


# support me
<p><a href="https://www.youtube.com/channel/UCm-UlQ6ygk4jkNfgFzlc2LA" rel="nofollow"><img src="https://camo.githubusercontent.com/cc79473d3c09ab1dcee9ae1a74d05fb7e7b57f62/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f73756263726962652d596f75547562652d7265642e737667" data-canonical-src="https://img.shields.io/badge/subcribe-YouTube-red.svg" style="max-width:100%;"></a></p>

A7Y Team (^_^)
