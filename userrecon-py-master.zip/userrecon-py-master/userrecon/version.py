__author__  = 'decoxviii'
__email__   = 'decoxviii@pm.me'
__license__ = 'MIT'
__version__ = '1.0.0'